USE Wellyson_Rudnick;

INSERT INTO tb_aluno (nr_matricula, nm_aluno, ds_endereco, nr_telefone, ds_email, ds_cidade, ds_uf, ds_bairro, nr_matriculaProf) VALUES
(1, 'Gabriel Santos', 'Rua das Palmeiras, 100', 999111222, 'gabriel@email.com', 'Joinville', 'SC', 'Centro', 1),
(2, 'Larissa Oliveira', 'Rua João Pessoa, 45', 988222333, 'larissa@email.com', 'Joinville', 'SC', 'América', 2),
(3, 'Pedro Henrique', 'Av. Getúlio Vargas, 320', 977333444, 'pedro@email.com', 'Joinville', 'SC', 'Bom Retiro', 3),
(4, 'Isabela Martins', 'Rua São Paulo, 90', 966444555, 'isabela@email.com', 'Joinville', 'SC', 'Glória', 4),
(5, 'Felipe Almeida', 'Rua Blumenau, 210', 955555666, 'felipe@email.com', 'Joinville', 'SC', 'Atiradores', 5),
(6, 'Natália Castro', 'Rua XV de Novembro, 123', 944666777, 'natalia@email.com', 'Joinville', 'SC', 'Saguaçu', 6),
(7, 'Vinícius Costa', 'Rua Dr. João Colin, 567', 933777888, 'vinicius@email.com', 'Joinville', 'SC', 'Boa Vista', 7),
(8, 'Beatriz Souza', 'Rua Timbó, 890', 922888999, 'beatriz@email.com', 'Joinville', 'SC', 'Paranaguamirim', 8),
(9, 'Eduardo Lima', 'Rua dos Expedicionários, 101', 911999000, 'eduardo@email.com', 'Joinville', 'SC', 'Itaum', 9),
(10, 'Camila Rocha', 'Rua das Acácias, 234', 900111222, 'camila@email.com', 'Joinville', 'SC', 'Iririú', 1),
(11, 'Lucas Mendes', 'Rua Jaraguá, 345', 899222333, 'lucas@email.com', 'Joinville', 'SC', 'Floresta', 2),
(12, 'Sofia Ribeiro', 'Rua Porto União, 456', 888333444, 'sofia@email.com', 'Joinville', 'SC', 'Costa e Silva', 3),
(13, 'Matheus Oliveira', 'Rua Guanabara, 567', 877444555, 'matheus@email.com', 'Joinville', 'SC', 'Fátima', 4),
(14, 'Fernanda Nogueira', 'Rua Blumenau, 678', 866555666, 'fernanda@email.com', 'Joinville', 'SC', 'Nova Brasília', 5),
(15, 'Daniel Ferreira', 'Rua Florianópolis, 789', 855666777, 'daniel@email.com', 'Joinville', 'SC', 'Jardim Paraíso', 6);