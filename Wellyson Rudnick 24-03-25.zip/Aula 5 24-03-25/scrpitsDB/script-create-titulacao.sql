use Wellyson_Rudnick;

CREATE TABLE tb_titulacao (
    cd_Titulacao INT(5) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    ds_titulacao VARCHAR(40) NOT NULL
);
