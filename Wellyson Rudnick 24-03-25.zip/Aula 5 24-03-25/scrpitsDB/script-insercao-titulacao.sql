USE Wellyson_Rudnick;

INSERT INTO tb_titulacao (ds_titulacao) VALUES
('Graduado'),
('Especialista'),
('Mestre'),
('Doutor'),
('PHD');

