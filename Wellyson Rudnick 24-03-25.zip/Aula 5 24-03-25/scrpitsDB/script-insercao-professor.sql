USE Wellyson_Rudnick;

INSERT INTO tb_professor (nr_matricula, nm_professor, nr_telefone, ds_email, ds_endereco, ds_cidade, ds_uf, ds_bairro, Cd_titulacao) VALUES
(1, 'Wellyson Rudnick', 999999999, 'welly@gmail.com', 'Rua 9 de março, 50', 'Joinville', 'SC', 'Centro', 1),
(2, 'Lucas Calixto', 888888888, 'lucas@gmail.com', 'Rua do Pricipe, 30', 'Joinville', 'SC', 'Centro', 2),
(3, 'João Paulo', 777777777, 'joao@gmail.com', 'Rua Princesa Isabel,40', 'Joinville', 'SC', 'Centro', 3),
(4, 'Maria Eduarda', 666666666, 'maria@gmail.com', 'Rua Itajaí, 67', 'Joinville', 'SC', 'Centro', 4),
(5, 'Ana Clara', 555555555, 'ana@gmail.com', 'Rua XV de Novembro, 214', 'Joinville', 'SC', 'Centro', 5),
(6, 'Ricardo Alves', 4799991111, 'ricardo.alves@email.com', 'Rua das Palmeiras, 150', 'Joinville', 'SC', 'Centro', 3),
(7, 'Mariana Souza', 4798882222, 'mariana.souza@email.com', 'Rua Orestes Guimarães, 200', 'Joinville', 'SC', 'Saguaçu', 2),
(8, 'Fernando Lima', 4797773333, 'fernando.lima@email.com', 'Rua Blumenau, 300', 'Joinville', 'SC', 'Atiradores', 4),
(9, 'Patrícia Nogueira', 4796664444, 'patricia.nogueira@email.com', 'Rua XV de Novembro, 400', 'Joinville', 'SC', 'Glória', 1);